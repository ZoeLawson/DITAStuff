<?xml version="1.0"?>

<xsl:stylesheet xmlns:xsl="http://www.w3.org/1999/XSL/Transform"
    xmlns:fo="http://www.w3.org/1999/XSL/Format"
    version="2.0">

    <xsl:import href="mcc_commons.xsl"/>
    <xsl:import href="mcc_flagging-from-preprocess.xsl"/>
    <xsl:import href="mcc_front-matter.xsl"/>
    <xsl:import href="../layout-masters.xsl"/>
    <xsl:import href="mcc_links.xsl"/>
    <xsl:import href="mcc_root-processing.xsl"/>
    <xsl:import href="mcc_static-content.xsl"/>
    <xsl:import href="mcc_tables.xsl"/>
    <xsl:import href="mcc_toc.xsl"/>
    <xsl:import href="mcc_topic.xsl"/>
</xsl:stylesheet>
<?xml version='1.0'?>
<xsl:stylesheet xmlns:xsl="http://www.w3.org/1999/XSL/Transform"
    xmlns:fo="http://www.w3.org/1999/XSL/Format"
    version="2.0">
    <xsl:variable name="mcc_color" select="'#1B355E'"/>
    
    <xsl:import href="mcc_basic-settings.xsl"/>
    <xsl:import href="mcc_commons-attr.xsl"/>
    <xsl:import href="mcc_front-matter-attr.xsl"/>
    <xsl:import href="mcc_layout-masters-attr.xsl"/>
    <xsl:import href="mcc_links-attr.xsl"/>
    <xsl:import href="mcc_lists-attr.xsl"/>
    <xsl:import href="mcc_pr-domain-attr.xsl"/>
    <xsl:import href="mcc_static-content-attr.xsl"/>
    <xsl:import href="mcc_tables-attr.xsl"/>
    <xsl:import href="mcc_toc-attr.xsl"/>
    <xsl:import href="mcc_topic-attr.xsl"/>
    <xsl:import href="mcc_ui-domain-attr.xsl"/>
    
</xsl:stylesheet>